#ifndef _INFO_H
#define _INFO_H

#include "../Includes/PluginCommonIncludes.h"
#include "Core.h"

namespace SaveData
{
	//class MountInfoRequest : public RequestBaseManaged
	//{
	//public:
	//	DirNameManaged dirName;

	//	void CopyTo(SceSaveDataDelete &destination, SceSaveDataDirName& sceDirName);
	//};

	//class Info
	//{
	//public:

	//	static void Delete(DeleteRequest* managedRequest, APIResult* result);
	//};
}

#endif	//_INFO_H

