using System;
using System.Runtime.InteropServices;

namespace Sony
{
    namespace NP
    {
        /// <summary>
        /// Activity Feed service related functionality.
        /// </summary>
        public class ActivityFeed
        {
            #region DLL Imports

            [DllImport("UnityNpToolkit2")]
            private static extern int PrxGetFeed(GetFeedRequest request, out APIResult result);

            [DllImport("UnityNpToolkit2")]
            private static extern int PrxPostInGameStory(PostInGameStoryRequest request, out APIResult result);

            [DllImport("UnityNpToolkit2")]
            private static extern int PrxSetLiked(SetLikedRequest request, out APIResult result);

            [DllImport("UnityNpToolkit2")]
            private static extern int PrxGetWhoLiked(GetWhoLikedRequest request, out APIResult result);


            [DllImport("UnityNpToolkit2")]
            private static extern int PrxPostPlayedWith(PostPlayedWithRequest request, out APIResult result);

            [DllImport("UnityNpToolkit2")]
            private static extern int PrxGetPlayedWith(GetPlayedWithRequest request, out APIResult result);

            [DllImport("UnityNpToolkit2")]
            private static extern int PrxGetSharedVideos(GetSharedVideosRequest request, out APIResult result);

            #endregion

            #region Common

            /// <summary>
            /// Defines the type of feed that can be retrieved.
            /// </summary>
            public enum FeedType
            {
                /// <summary>Invalid type </summary>
                Invalid = 0,
                /// <summary>User feed</summary>
                UserFeed,
                /// <summary>User news</summary>
                UserNews,
                /// <summary>Title feed</summary>
                TitleFeed,
                /// <summary>Title news</summary>
                TitleNews
            };

            /// <summary>
            /// Defines the type of story that can be retrieved.
            /// </summary>
            public enum StoryType
            {
                /// <summary>An In-Game story</summary>
                InGamePost,
                /// <summary>A "Players Met" story</summary>
				PlayedWith,
                /// <summary>A video upload story</summary>
				VideoUpload,
                /// <summary>A broadcast story</summary>
				Broadcasting
            };

            /// <summary>
            /// Defines the type of feed that can be retrieved.
            /// </summary>
            public enum ActionType
            {
                /// <summary>Invalid type </summary>
                Invalid = 0,
                /// <summary>Open a URL</summary>
                Url,
                /// <summary>Open a PlayStation�Store product or category</summary>
                Store,
                /// <summary>Start a game with parameters</summary>
                StartGame,
            };

            /// <summary>
            /// Represents an identifier for a story.
            /// </summary>
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
            public struct StoryId
            {
                /// <summary>
                /// The size of a story ID.
                /// </summary>
                public const int STORY_ID_LEN = 64;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STORY_ID_LEN + 1)]
                internal string id;

                /// <summary>
                /// The ID of the story.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the string is more than <see cref="STORY_ID_LEN"/> characters.</exception>
                public string Id
                {
                    get { return id; }
                    set
                    {
                        if (value.Length > STORY_ID_LEN)
                        {
                            throw new NpToolkitException("The size of the string is more than " + STORY_ID_LEN + " characters.");
                        }
                        id = value;
                    }
                }

                // Read data from PRX marshaled buffer
                internal void Read(MemoryBuffer buffer)
                {
                    buffer.ReadString(ref id);
                }
            }

            /// <summary>
            /// Represents a story caption. A caption is the text that is
            /// displayed in a story on the system software.     
            /// </summary>
            public struct Caption
            {
                /// <summary>
                /// The maximum length allowed on a caption.
                /// </summary>
                public const int CAPTION_MAX_LEN = 511;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 6)]
                internal string languageCode;


                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = CAPTION_MAX_LEN + 1)]
                internal string caption;

                /// <summary>
				/// The language of the caption.
				/// </summary>
				/// <remarks>
				/// Takes a copy of the language code or returns a copy. The language code must be assign explicitly. 
				/// </remarks>
				public Core.LanguageCode LanguageCode
                {
                    get
                    {
                        Core.LanguageCode cc = new Core.LanguageCode();
                        cc.code = languageCode;
                        return cc;
                    }

                    set
                    {
                        languageCode = value.code;
                    }
                }

                /// <summary>
                /// The caption string for the story.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the string is more than <see cref="CAPTION_MAX_LEN"/> characters.</exception>
                public string CaptionText
                {
                    get { return caption; }
                    set
                    {
                        if (value.Length > CAPTION_MAX_LEN)
                        {
                            throw new NpToolkitException("The size of the string is more than " + CAPTION_MAX_LEN + " characters.");
                        }
                        caption = value;
                    }
                }

                // Read data from PRX marshaled buffer
                internal void Read(MemoryBuffer buffer)
                {
                    buffer.ReadString(ref languageCode);
                    buffer.ReadString(ref caption);
                }

            }

            /// <summary>
            /// Represents media that can be attached to a story. This can contain small images,
            /// large images and video URLs that are shown to the user in the system software.
            /// </summary>
            public struct Media
            {
                /// <summary>
                /// The maximum size the URL can have.
                /// </summary>
                public const int URL_MAX_LEN = 255;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = URL_MAX_LEN + 1)]
                internal string largeImageUrl;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = URL_MAX_LEN + 1)]
                internal string videoUrl;

                /// <summary>
                /// The URL of the image to be used when the system software displays individual feed stories. This can be omitted, but it is highly recommended.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the string is more than <see cref="URL_MAX_LEN"/> characters.</exception>
                public string LargeImageUrl
                {
                    get { return largeImageUrl; }
                    set
                    {
                        if (value.Length > URL_MAX_LEN)
                        {
                            throw new NpToolkitException("The size of the string is more than " + URL_MAX_LEN + " characters.");
                        }
                        largeImageUrl = value;
                    }
                }

                /// <summary>
                /// The URL of video to be used when the system software displays individual feed stories. If it is provided, this will be used instead of <see cref="LargeImageUrl"/>. It can be omitted.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the string is more than <see cref="URL_MAX_LEN"/> characters.</exception>
                public string VideoUrl
                {
                    get { return videoUrl; }
                    set
                    {
                        if (value.Length > URL_MAX_LEN)
                        {
                            throw new NpToolkitException("The size of the string is more than " + URL_MAX_LEN + " characters.");
                        }
                        videoUrl = value;
                    }
                }

                // Read data from PRX marshaled buffer
                internal void Read(MemoryBuffer buffer)
                {
                    buffer.ReadString(ref largeImageUrl);
                    buffer.ReadString(ref videoUrl);
                }
            }

            /// <summary>
            ///  Represents the text that is displayed on the Action Button in the system software.
            /// </summary>
            public struct ButtonCaption
            {
                /// <summary>
                /// The maximum size of the text allowed on a caption button.
                /// </summary>
                public const int TEXT_MAX_LEN = 20;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 6)]
                internal string languageCode;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = TEXT_MAX_LEN + 1)]
                internal string text;

                /// <summary>
                /// The language of the caption.
                /// </summary>
                /// <remarks>
                /// Takes a copy of the language code or returns a copy. The language code must be assign explicitly. 
                /// </remarks>
                public Core.LanguageCode LanguageCode
                {
                    get
                    {
                        Core.LanguageCode cc = new Core.LanguageCode();
                        cc.code = languageCode;
                        return cc;
                    }

                    set
                    {
                        languageCode = value.code;
                    }
                }

                /// <summary>
                /// The text of the caption.
                /// </summary>
                public string Text
                {
                    get { return text; }
                    set
                    {
                        if (value.Length > TEXT_MAX_LEN)
                        {
                            throw new NpToolkitException("The size of the string is more than " + TEXT_MAX_LEN + " characters.");
                        }
                        text = value;
                    }
                }
            }

            /// <summary>
            /// Represents a story action. The action can be to launch the PlayStation�Store to a given product, link to a website, or
            /// launch a game with custom arguments.
            /// </summary>
            public struct Action
            {
                /// <summary>
                /// The maximum amount of caption buttons to add.
                /// </summary>
                public const int MAX_BUTTON_CAPTIONS = 32;

                /// <summary>
                /// The maximum size allowed on the URL string.
                /// </summary>
                public const int URL_MAX_LEN = 255;

                /// <summary>
                /// The maximum size of the PlayStation�Store label (Product Label or Category Label).
                /// </summary>
                public const int STORE_LABEL_MAX_LEN = 31;

                /// <summary>
                /// The maximum size the pointer containing the arguments to start the application can have.
                /// </summary>
                public const int START_GAME_ARGS_MAX = 2083;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = URL_MAX_LEN + 1)]
                internal string imageUrl;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = URL_MAX_LEN + 1)]
                internal string uri;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = STORE_LABEL_MAX_LEN + 1)]
                internal string storeLabel;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = START_GAME_ARGS_MAX + 1)]
                internal string startGameArguments;

                [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_BUTTON_CAPTIONS)]
                internal ButtonCaption[] buttonCaptions;

                internal UInt32 storeServiceLabel;

                internal ActionType type;

                /// <summary>
				/// The URL of the image to display on the button. Pixel size: 68x68. This can be omitted.
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if the string is more than <see cref="URL_MAX_LEN"/> characters.</exception>
				public string ImageUrl
                {
                    get { return imageUrl; }
                    set
                    {
                        if (value.Length > URL_MAX_LEN)
                        {
                            throw new NpToolkitException("The size of the string is more than " + URL_MAX_LEN + " characters.");
                        }
                        imageUrl = value;
                    }
                }

                /// <summary>
				/// The URI of the web page to open. This is only used when <see cref="ActionType"/> is set to <see cref="ActionType.Url"/>
				/// </summary>
				/// <exception cref="NpToolkitException">Will throw an exception if the string is more than <see cref="URL_MAX_LEN"/> characters.</exception>
				public string Uri
                {
                    get { return uri; }
                    set
                    {
                        if (value.Length > URL_MAX_LEN)
                        {
                            throw new NpToolkitException("The size of the string is more than " + URL_MAX_LEN + " characters.");
                        }
                        uri = value;
                    }
                }

                /// <summary>
                /// The product label or category label. This is only used when <see cref="ActionType"/> is set to <see cref="ActionType.Store"/>
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the string is more than <see cref="STORE_LABEL_MAX_LEN"/> characters.</exception>
                public string StoreLabel
                {
                    get { return storeLabel; }
                    set
                    {
                        if (value.Length > STORE_LABEL_MAX_LEN)
                        {
                            throw new NpToolkitException("The size of the string is more than " + STORE_LABEL_MAX_LEN + " characters.");
                        }
                        storeLabel = value;
                    }
                }

                /// <summary>
                /// The arbitrary character string to be passed to the started application. This is only used when <see cref="ActionType"/> is set to <see cref="ActionType.StartGame"/>
                /// See the <see cref="Main.LaunchAppEventResponse"/> notification for handling arguments passed when an app is launched from an activity feed.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the string is more than <see cref="START_GAME_ARGS_MAX"/> characters.</exception>
                public string StartGameArguments
                {
                    get { return startGameArguments; }
                    set
                    {
                        if (value.Length > START_GAME_ARGS_MAX)
                        {
                            throw new NpToolkitException("The size of the string is more than " + START_GAME_ARGS_MAX + " characters.");
                        }
                        startGameArguments = value;
                    }
                }

                /// <summary>
                /// The text to display on the button.
                /// </summary>
                /// <remarks>
                /// Takes a copy of the array or returns a copy. Changing the array set or returned by this property won't change the stored data in this instance.
                /// </remarks>
                /// <exception cref="NpToolkitException">Will throw an exception if the array is more than <see cref="MAX_BUTTON_CAPTIONS"/>.</exception>
                public ButtonCaption[] ButtonCaptions
                {
                    get
                    {
                        ButtonCaption[] temp = new ButtonCaption[MAX_BUTTON_CAPTIONS];

                        Array.Copy(buttonCaptions, temp, MAX_BUTTON_CAPTIONS);

                        return temp;
                    }
                    set
                    {
                        if (value != null)
                        {
                            if (value.Length > MAX_BUTTON_CAPTIONS)
                            {
                                throw new NpToolkitException("The size of the button captions array is more than " + MAX_BUTTON_CAPTIONS);
                            }

                            buttonCaptions = new ButtonCaption[MAX_BUTTON_CAPTIONS];

                            value.CopyTo(buttonCaptions, 0);
                        }
                    }
                }

                /// <summary>
                ///  The service label for the specified PlayStation�Store product or category. Only used when <see cref="ActionType"/> is set to <see cref="ActionType.Store"/>
                /// </summary>
                public UInt32 StoreServiceLabel
                {
                    get { return storeServiceLabel; }
                    set { storeServiceLabel = value; }
                }

                /// <summary>
                /// The action type.
                /// </summary>
                public ActionType ActionType
                {
                    get { return type; }
                    set { type = value; }
                }

            }

            /// <summary>
            /// Represents user information from a story.
            /// </summary>
            public class StoryUser
            {
                /// <summary>
                /// The maximum size the URL string can be.
                /// </summary>
                public const int URL_MAX_LEN = 255;

                internal Core.OnlineUser user = new Core.OnlineUser();
                internal string avatarUrl;
                internal Profiles.RealName realName = new Profiles.RealName();

                /// <summary>
				/// The user's ID.
				/// </summary>
				public Core.OnlineUser User { get { return user; } }

                /// <summary>
				/// The user's avatar URL.
				/// </summary>
				public string AvatarUrl { get { return avatarUrl; } }

                /// <summary>
				/// The user's real name. This may not be set depending on the remote user's privacy and friend status.
				/// </summary>
				public Profiles.RealName RealName { get { return realName; } }

                // Read data from PRX marshaled buffer
                internal void Read(MemoryBuffer buffer)
                {
                    buffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.StoryUserBegin);

                    user.Read(buffer);

                    buffer.ReadString(ref avatarUrl);

                    realName.Read(buffer);

                    buffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.StoryUserEnd);
                }
            }

            /// <summary>
            /// Represents a story from an Activity Feed
            /// It contains comments, captions, media, and actions among other things.
            /// </summary>
            public class Story
            {
                internal string creationDate;
                internal string userComment;
                internal Media media;
                internal StoryId storyId;
                internal Caption caption;
                internal StoryType storyType;
                internal Int32 subType;
                internal StoryUser postCreator = new StoryUser();
                internal UInt32 numLikes;
                internal UInt32 numComments;
                internal bool isReshareable;
                internal bool isLiked;

                /// <summary>
                /// The date that the post was created (RFC3339/ISO8602 format).
                /// </summary>
                public string CreationDate { get { return creationDate; } }

                /// <summary>
                ///  A character string input by user. Note that a vulgarity filter will be applied.
                /// </summary>
                public string UserComment { get { return userComment; } }

                /// <summary>
                /// The images and video links associated with this story.
                /// </summary>
                public Media Media { get { return media; } }

                /// <summary>
                /// The ID for the story.
                /// </summary>
                public StoryId StoryId { get { return storyId; } }

                /// <summary>
                /// The story caption.
                /// </summary>
                public Caption Caption { get { return caption; } }

                /// <summary>
                /// The type of story.
                /// </summary>
                public StoryType StoryType { get { return storyType; } }

                /// <summary>
                /// A key for collecting multiple stories into a condensed story.
                /// </summary>
                public Int32 SubType { get { return subType; } }

                /// <summary>
                /// The user who created the post.
                /// </summary>
                public StoryUser PostCreator { get { return postCreator; } }

                /// <summary>
                /// The number of likes for this story.
                /// </summary>
                public UInt32 NumLikes { get { return numLikes; } }

                /// <summary>
                /// The number of comments for this story.
                /// </summary>
                public UInt32 NumComments { get { return numComments; } }

                /// <summary>
                /// A flag that specifies whether the story is re-shareable.
                /// </summary>
                public bool IsReshareable { get { return isReshareable; } }

                /// <summary>
                /// A flag that specifies whether this story is liked by the current user.
                /// </summary>
                public bool IsLiked { get { return isLiked; } }


                // Read data from PRX marshaled buffer
                internal void Read(MemoryBuffer buffer)
                {
                    buffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.StoryBegin);

                    buffer.ReadString(ref creationDate);
                    buffer.ReadString(ref userComment);

                    media.Read(buffer);
                    storyId.Read(buffer);
                    caption.Read(buffer);
                    
                    storyType = (StoryType)buffer.ReadUInt32();

                    subType = buffer.ReadInt32();

                    postCreator.Read(buffer);

                    numLikes = buffer.ReadUInt32();
                    numComments = buffer.ReadUInt32();

                    isReshareable = buffer.ReadBool();
                    isLiked = buffer.ReadBool();

                    buffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.StoryEnd);
                }
            }

            /// <summary>
            /// Represents a "Players Met" story.
            /// </summary>
            public class PlayedWithStory
            {
                internal StoryId storyId;
                internal StoryUser[] users;
                internal string titleName;
                internal string date;
                internal Core.TitleId titleId = new Core.TitleId();
                internal string playedWithDescription;

                /// <summary>
                /// The ID for the story.
                /// </summary>
                public StoryId StoryId { get { return storyId; } }

                /// <summary>
                /// The users that were met.
                /// </summary>
                public StoryUser[] Users { get { return users; } }

                /// <summary>
                /// The title name.
                /// </summary>
                public string TitleName { get { return titleName; } }

                /// <summary>
                ///  The date that the users met each other (RFC3339/ISO8602 format).
                /// </summary>
                public string Date { get { return date; } }

                /// <summary>
                /// The Title ID of the application played.
                /// </summary>
                public Core.TitleId TitleId { get { return titleId; } }

                /// <summary>
                /// The description of the "Players Met" story.
                /// </summary>
                public string PlayedWithDescription { get { return playedWithDescription; } }

 
                // Read data from PRX marshaled buffer
                internal void Read(MemoryBuffer buffer)
                {
                    buffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.StoryBegin);

                    storyId.Read(buffer);

                    UInt32 numUsers = buffer.ReadUInt32();

                    users = new StoryUser[numUsers];

                    for (int i = 0; i < numUsers; i++)
                    {
                        users[i] = new StoryUser();
                        users[i].Read(buffer);
                    }

                    buffer.ReadString(ref titleName);
                    buffer.ReadString(ref date);

                    titleId.Read(buffer);

                    buffer.ReadString(ref playedWithDescription);

                    buffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.StoryEnd);
                }
            }

            /// <summary>
            /// Represents a video that has been shared by a user. It contains
            /// information about the creation date and user, and also
            /// about the social network service that it has been shared to.
            /// </summary>
            public class SharedVideo
            {
                internal StoryId storyId;
                internal Caption caption;
                internal StoryUser sourceCreator = new StoryUser();
                internal string snType;
                internal string videoId;
                internal string creationDate;
                internal string videoDuration;
                internal string comment;

                /// <summary>
                /// The unique ID for this story.
                /// </summary>
                public StoryId StoryId { get { return storyId; } }

                /// <summary>
                /// The story caption.
                /// </summary>
                public Caption Caption { get { return caption; } }

                /// <summary>
                /// The source user for this story.
                /// </summary>
                public StoryUser SourceCreator { get { return sourceCreator; } }

                /// <summary>
                /// The social network type that the screenshot was posted to.
                /// </summary>
                public string SNType { get { return snType; } }

                /// <summary>
                /// The ID for the photo stored on the social network.
                /// </summary>
                public string VideoId { get { return videoId; } }

                /// <summary>
                /// The date that the post was created (RFC3339/ISO8602 format).
                /// </summary>
                public string CreationDate { get { return creationDate; } }

                /// <summary>
                /// The duration of the posted video.
                /// </summary>
                public string VideoDuration { get { return videoDuration; } }

                /// <summary>
                /// The user comment for this story.
                /// </summary>
                public string Comment { get { return comment; } }


                // Read data from PRX marshaled buffer
                internal void Read(MemoryBuffer buffer)
                {
                    buffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.SharedVideoBegin);

                    storyId.Read(buffer);
                    caption.Read(buffer);
                    sourceCreator.Read(buffer);

                    buffer.ReadString(ref snType);
                    buffer.ReadString(ref videoId);
                    buffer.ReadString(ref creationDate);
                    buffer.ReadString(ref videoDuration);
                    buffer.ReadString(ref comment);

                    buffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.SharedVideoEnd);
                }
            }

            #endregion

            #region Requests		

            /// <summary>
            /// Represents a request to get a feed
            /// </summary>
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
            public class GetFeedRequest : RequestBase
            {
                /// <summary>
                /// The maximum number of elements a page can have.
                /// </summary>
                public const int MAX_PAGE_SIZE = 100;

                /// <summary>
                /// The default number of elements per page.
                /// </summary>
                public const int DEFAULT_PAGE_SIZE = 20;

                internal Core.NpAccountId user;
                internal FeedType feedType;
                internal UInt32 offset;
                internal UInt32 pageSize;

                /// <summary>
                /// The user whose feed will be retrieved
                /// </summary>
                public Core.NpAccountId User
                {
                    get { return user; }
                    set { user = value; }
                }

                /// <summary>
                /// The type of feed that we want to retrieve
                /// </summary>
                public FeedType FeedType
                {
                    get { return feedType; }
                    set { feedType = value; }
                }

                /// <summary>
                /// The starting index if paging is used because many feeds exist
                /// </summary>
                public UInt32 Offset
                {
                    get { return offset; }
                    set { offset = value; }
                }

                /// <summary>
                /// The maximum number of feeds to return. This defaults to <see cref="DEFAULT_PAGE_SIZE"/>
                /// </summary>
                public UInt32 PageSize
                {
                    get { return pageSize; }
                    set { pageSize = value; }
                }

                /// <summary>
                /// Initializes a new instance of the <see cref="GetFeedRequest"/> class.
                /// </summary>
                public GetFeedRequest()
                    : base(ServiceTypes.ActivityFeed, FunctionTypes.ActivityFeedGetFeed)
                {
                    pageSize = DEFAULT_PAGE_SIZE;
                }
            }

            /// <summary>
            ///Represents a request to post an "In Game" story.
            /// </summary>
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
            public class PostInGameStoryRequest : RequestBase
            {
                /// <summary>
                /// The maximum size of the user comment.
                /// </summary>
                public const int USER_COMMENT_MAX_LEN = 1000;

                /// <summary>
                /// The maximum number of actions allowed.
                /// </summary>
                public const int MAX_ACTIONS = 3;

                /// <summary>
                /// The maximum number of captions
                /// </summary>
                public const int MAX_CAPTIONS = 1024;


                [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_ACTIONS)]
                internal Action[] actions;

                [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_CAPTIONS)]
                internal Caption[] captions;

                UInt32 numCaptions;

                [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_CAPTIONS)]
                internal Caption[] condensedCaptions;

                UInt32 numCondensedCaptions;

                internal Media media;

                internal Int32 subType;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = USER_COMMENT_MAX_LEN + 1)]
                internal string userComment;

                /// <summary>
                /// The actions related to this story. This can be omitted.
                /// The array size must not exceed <see cref="MAX_ACTIONS"/>.
                /// </summary>
                /// <remarks>
                /// Takes a copy of the array or returns a copy. Changing the array set or returned by this property won't change the stored data in this instance.
                /// </remarks>
                /// <exception cref="NpToolkitException">Will throw an exception if the array is more than <see cref="MAX_ACTIONS"/>.</exception>
                public Action[] Actions
                {
                    get
                    {
                        Action[] tempActions = new Action[MAX_ACTIONS];

                        Array.Copy(actions, tempActions, MAX_ACTIONS);

                        return tempActions;
                    }
                    set
                    {
                        if (value != null)
                        {
                            if (value.Length > MAX_ACTIONS)
                            {
                                throw new NpToolkitException("The size of the actions array is more than " + MAX_ACTIONS);
                            }

                            actions = new Action[MAX_ACTIONS];

                            value.CopyTo(actions, 0);
                        }
                    }
                }

                /// <summary>
                /// The captions for this story. For example, "$USER_NAME_OR_ID got a car".
                /// </summary>
                /// <remarks>
                /// Takes a copy of the array or returns a copy. Changing the array set or returned by this property won't change the stored data in this instance.
                /// </remarks>
                /// <exception cref="NpToolkitException">Will throw an exception if the array is more than <see cref="MAX_CAPTIONS"/>.</exception>
                public Caption[] Captions
                {
                    get
                    {
                        Caption[] tempCaptions = new Caption[numCaptions];

                        Array.Copy(captions, tempCaptions, numCaptions);

                        return tempCaptions;
                    }
                    set
                    {
                        if (value != null)
                        {
                            if (value.Length > MAX_CAPTIONS)
                            {
                                throw new NpToolkitException("The size of the captions array is more than " + MAX_CAPTIONS);
                            }

                            numCaptions = (uint)value.Length;

                            captions = new Caption[MAX_CAPTIONS];

                            value.CopyTo(captions, 0);
                        }
                    }
                }

                /// <summary>
                /// The captions used when this story is collected in a condensed story. For example, "$USER_NAME_OR_ID got $STORY_COUNT cars".
                /// </summary>
                /// <remarks>
                /// Takes a copy of the array or returns a copy. Changing the array set or returned by this property won't change the stored data in this instance.
                /// </remarks>
                /// <exception cref="NpToolkitException">Will throw an exception if the array is more than <see cref="MAX_CAPTIONS"/>.</exception>
                public Caption[] CondensedCaptions
                {
                    get
                    {
                        Caption[] tempCaptions = new Caption[numCondensedCaptions];

                        Array.Copy(condensedCaptions, tempCaptions, numCondensedCaptions);

                        return tempCaptions;
                    }
                    set
                    {
                        if (value != null)
                        {
                            if (value.Length > MAX_CAPTIONS)
                            {
                                throw new NpToolkitException("The size of the condensed captions array is more than " + MAX_CAPTIONS);
                            }

                            numCondensedCaptions = (uint)value.Length;

                            condensedCaptions = new Caption[MAX_CAPTIONS];

                            value.CopyTo(condensedCaptions, 0);
                        }
                    }
                }

                /// <summary>
                /// The image and video URLs for this story.
                /// </summary>
                public Media Media
                {
                    get { return media; }
                    set { media = value; }
                }

                /// <summary>
                /// The key to use when collecting multiple stories into a condensed story.
                /// </summary>
                public Int32 SubType
                {
                    get { return subType; }
                    set { subType = value; }
                }

                /// <summary>
                /// A character string input by the user. Note that a vulgarity filter will be applied. This can be omitted.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the string is more than <see cref="USER_COMMENT_MAX_LEN"/> characters.</exception>
                public string UserComment
                {
                    get { return userComment; }
                    set
                    {
                        if (value.Length > USER_COMMENT_MAX_LEN)
                        {
                            throw new NpToolkitException("The size of the string is more than " + USER_COMMENT_MAX_LEN + " characters.");
                        }
                        userComment = value;
                    }
                }

                /// <summary>
                /// Initializes a new instance of the <see cref="PostInGameStoryRequest"/> class.
                /// </summary>
                public PostInGameStoryRequest()
                    : base(ServiceTypes.ActivityFeed, FunctionTypes.ActivityFeedPostInGameStory)
                {
                    actions = new Action[MAX_ACTIONS];
                }
            }

            /// <summary>
            /// Represents a request to like or unlike a story.
            /// </summary>
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
            public class SetLikedRequest : RequestBase
            {
                internal StoryId storyId;

                [MarshalAs(UnmanagedType.I1)]
                internal bool isLiked;

                /// <summary>
                /// The ID for the story.
                /// </summary>
                public StoryId StoryId
                {
                    get { return storyId; }
                    set { storyId = value; }
                }

                /// <summary>
                /// A flag that specifies whether to like the story. A value of false indicates the story was not liked.
                /// </summary>
                public bool IsLiked
                {
                    get { return isLiked; }
                    set { isLiked = value; }
                }

                /// <summary>
                /// Initializes a new instance of the <see cref="SetLikedRequest"/> class.
                /// </summary>
                public SetLikedRequest()
                    : base(ServiceTypes.ActivityFeed, FunctionTypes.ActivityFeedSetLiked)
                {

                }
            }

            /// <summary>
            /// Represents a request to find who liked a story.
            /// </summary>
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
            public class GetWhoLikedRequest : RequestBase
            {
                /// <summary>
                /// The maximum number of elements a page can have.
                /// </summary>
                public const int MAX_PAGE_SIZE = 100;

                /// <summary>
                /// The default number of elements per page.
                /// </summary>
                public const int DEFAULT_PAGE_SIZE = 20;

                internal Core.NpAccountId lastUserRetrieved;
                internal StoryId storyId;
                internal UInt32 pageSize;

                /// <summary>
                /// Specifies the last user in the previously obtained user array. This is used when the users are divided into multiple pages. The specified user will be used as an index.
                /// </summary>
                public Core.NpAccountId LastUserRetrieved
                {
                    get { return lastUserRetrieved; }
                    set { lastUserRetrieved = value; }
                }

                /// <summary>
                /// The ID for the story.
                /// </summary>
                public StoryId StoryId
                {
                    get { return storyId; }
                    set { storyId = value; }
                }

                /// <summary>
                /// The maximum number of users to return. This defaults to <see cref="DEFAULT_PAGE_SIZE"/>
                /// </summary>
                public UInt32 PageSize
                {
                    get { return pageSize; }
                    set { pageSize = value; }
                }

                /// <summary>
                /// Initializes a new instance of the <see cref="GetWhoLikedRequest"/> class.
                /// </summary>
                public GetWhoLikedRequest()
                    : base(ServiceTypes.ActivityFeed, FunctionTypes.ActivityFeedGetWhoLiked)
                {
                    pageSize = DEFAULT_PAGE_SIZE;
                }
            }

            /// <summary>
            /// Represents a request to post a "Players Met" story.
            /// </summary>
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
            public class PostPlayedWithRequest : RequestBase
            {
                /// <summary>
                /// The maximum size the description can have
                /// </summary>
                public const int DESCRIPTION_MAX_LEN = 2083;

                /// <summary>
                /// The maximum amount of users that can be posted as "Players Met"
                /// </summary>
                public const int MAX_USERS = 19;


                [MarshalAs(UnmanagedType.ByValArray, SizeConst = MAX_USERS)]
                internal Core.NpAccountId[] userIds;
                internal UInt32 numUsers;

                [MarshalAs(UnmanagedType.ByValTStr, SizeConst = DESCRIPTION_MAX_LEN + 1)]
                internal string playedWithDescription;

                /// <summary>
                /// The users that were met.
                /// The array size must not exceed <see cref="MAX_USERS"/>.
                /// </summary>
                /// <remarks>
                /// Takes a copy of the array or returns a copy. Changing the array set or returned by this property won't change the stored data in this instance.
                /// </remarks>
                /// <exception cref="NpToolkitException">Will throw an exception if the array is more than <see cref="MAX_USERS"/>.</exception>
                public Core.NpAccountId[] UserIds
                {
                    get
                    {
                        Core.NpAccountId[] temp = new Core.NpAccountId[numUsers];

                        Array.Copy(userIds, temp, numUsers);

                        return temp;
                    }
                    set
                    {
                        if (value != null)
                        {
                            if (value.Length > MAX_USERS)
                            {
                                throw new NpToolkitException("The size of the users array is more than " + MAX_USERS);
                            }

                            numUsers = (uint)value.Length;

                            userIds = new Core.NpAccountId[MAX_USERS];

                            value.CopyTo(userIds, 0);
                        }
                        else
                        {
                            numUsers = 0;
                        }
                    }
                }

                /// <summary>
                /// The description of the "Players Met" story.
                /// </summary>
                /// <exception cref="NpToolkitException">Will throw an exception if the string is more than <see cref="DESCRIPTION_MAX_LEN"/> characters.</exception>
                public string PlayedWithDescription
                {
                    get { return playedWithDescription; }
                    set
                    {
                        if (value.Length > DESCRIPTION_MAX_LEN)
                        {
                            throw new NpToolkitException("The size of the string is more than " + DESCRIPTION_MAX_LEN + " characters.");
                        }
                        playedWithDescription = value;
                    }
                }

                /// <summary>
                /// Initializes a new instance of the <see cref="PostPlayedWithRequest"/> class.
                /// </summary>
                public PostPlayedWithRequest()
                    : base(ServiceTypes.ActivityFeed, FunctionTypes.ActivityFeedPostPlayedWith)
                {
                }
            }

            /// <summary>
            /// Represents a request to get a list of "Players Met" stories.
            /// </summary>
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
            public class GetPlayedWithRequest : RequestBase
            {
                /// <summary>
                /// Initializes a new instance of the <see cref="GetPlayedWithRequest"/> class.
                /// </summary>
                public GetPlayedWithRequest()
                    : base(ServiceTypes.ActivityFeed, FunctionTypes.ActivityFeedGetPlayedWith)
                {
                }
            }

            /// <summary>
            /// Represents a request to get videos that have been shared by a user.
            /// </summary>
            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
            public class GetSharedVideosRequest : RequestBase
            {
                internal Core.NpAccountId user;

                /// <summary>
                /// The user whose videos to retrieve.
                /// </summary>
                public Core.NpAccountId User
                {
                    get { return user; }
                    set { user = value; }
                }

                /// <summary>
                /// Initializes a new instance of the <see cref="GetSharedVideosRequest"/> class.
                /// </summary>
                public GetSharedVideosRequest()
                    : base(ServiceTypes.ActivityFeed, FunctionTypes.ActivityFeedGetSharedVideos)
                {
                }
            }


            #endregion

            #region Post InGame Story

            /// <summary>
            /// Posts a custom feed containing an In-Game story that is configurable by the application.
            /// </summary>
            /// <param name="request">The information to post</param>
            /// <param name="response">This response contains the return code</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int PostInGameStory(PostInGameStoryRequest request, Core.EmptyResponse response)
            {
                APIResult result;

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxPostInGameStory(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion

            #region Get Feed


            /// <summary>
            /// Represents a list of retrieved stories
            /// </summary>
            public class FeedResponse : ResponseBase
            {
                internal Story[] stories;

                /// <summary>
                /// The stories that were returned
                /// </summary>
                public Story[] Stories { get { return stories; } }

                /// <summary>
                /// Read the response data from the plug-in
                /// </summary>
                /// <param name="id">The request id.</param>
                /// <param name="apiCalled">The API called.</param>
                /// <param name="request">The Request object.</param>
                protected internal override void ReadResult(UInt32 id, FunctionTypes apiCalled, RequestBase request)
                {
                    base.ReadResult(id, apiCalled, request);

                    APIResult result;

                    MemoryBuffer readBuffer = BeginReadResponseBuffer(id, apiCalled, out result);

                    if (result.RaiseException == true) throw new NpToolkitException(result);

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.GetFeedBegin);

                    UInt32 numStories = readBuffer.ReadUInt32();

                    stories = new Story[numStories];

                    for(int i = 0; i < numStories; i++)
                    {
                        stories[i] = new Story();
                        stories[i].Read(readBuffer);
                    }

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.GetFeedEnd);

                    EndReadResponseBuffer(readBuffer);
                }
            }

            /// <summary>
            /// Retrieves custom feeds from different users This can be a user feed, user news, title feed, or title news
            /// </summary>
            /// <param name="request">The information to obtain the feeds </param>
            /// <param name="response">This response contains the return code and the feed information</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int GetFeed(GetFeedRequest request, FeedResponse response)
            {
                APIResult result;

                if (Main.initResult.sceSDKVersion > 0x07500000)
                {
                    if (request.FeedType == FeedType.UserFeed || request.FeedType == FeedType.UserNews)
                    {
                        throw new NpToolkitException("This request is not available in SDK " + Main.initResult.SceSDKVersion.ToString() + ". Only available in SDK 7.0 or less.");
                    }
                }

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxGetFeed(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion

            #region Set Liked

            /// <summary>
            /// Marks a feed as liked or not liked.
            /// </summary>
            /// <param name="request">The information to update the feed </param>
            /// <param name="response">This response contains the return code</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int SetLiked(SetLikedRequest request, Core.EmptyResponse response)
            {
                APIResult result;

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxSetLiked(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion

            #region Get Who Liked

            /// <summary>
            /// Represents the users who liked a given story.
            /// </summary>
            public class UsersWhoLikedResponse : ResponseBase
            {
                internal StoryUser[] users;

                /// <summary>
                /// The users who liked the story.
                /// </summary>
                public StoryUser[] Users { get { return users; } }

                /// <summary>
                /// Read the response data from the plug-in
                /// </summary>
                /// <param name="id">The request id.</param>
                /// <param name="apiCalled">The API called.</param>
                /// <param name="request">The Request object.</param>
                protected internal override void ReadResult(UInt32 id, FunctionTypes apiCalled, RequestBase request)
                {
                    base.ReadResult(id, apiCalled, request);

                    APIResult result;

                    MemoryBuffer readBuffer = BeginReadResponseBuffer(id, apiCalled, out result);

                    if (result.RaiseException == true) throw new NpToolkitException(result);

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.UsersWhoLikedBegin);

                    UInt32 numUsers = readBuffer.ReadUInt32();

                    users = new StoryUser[numUsers];

                    for (int i = 0; i < numUsers; i++)
                    {
                        users[i] = new StoryUser();
                        users[i].Read(readBuffer);
                    }

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.UsersWhoLikedEnd);

                    EndReadResponseBuffer(readBuffer);
                }
            }


            /// <summary>
            /// Gets a list of users who liked a feed.
            /// </summary>
            /// <param name="request">A reference to a <see cref="GetWhoLikedRequest"/> object containing the information to make the request.  </param>
            /// <param name="response">This response contains the return code and retrieved request data</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int GetWhoLiked(GetWhoLikedRequest request, UsersWhoLikedResponse response)
            {
                APIResult result;

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxGetWhoLiked(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion

            #region Post Played With

            /// <summary>
            /// Sets a list of users as "Players Met" in the system.
            /// </summary>
            /// <param name="request">The information to post</param>
            /// <param name="response">This response contains the return code</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int PostPlayedWith(PostPlayedWithRequest request, Core.EmptyResponse response)
            {
                APIResult result;

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxPostPlayedWith(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion

            #region Get Played With

            /// <summary>
            /// Represents a list of "Players Met" stories.
            /// </summary>
            public class PlayedWithFeedResponse : ResponseBase
            {
                internal PlayedWithStory[] stories;

                /// <summary>
                /// The stories that were returned
                /// </summary>
                public PlayedWithStory[] Stories { get { return stories; } }

                /// <summary>
                /// Read the response data from the plug-in
                /// </summary>
                /// <param name="id">The request id.</param>
                /// <param name="apiCalled">The API called.</param>
                /// <param name="request">The Request object.</param>
                protected internal override void ReadResult(UInt32 id, FunctionTypes apiCalled, RequestBase request)
                {
                    base.ReadResult(id, apiCalled, request);

                    APIResult result;

                    MemoryBuffer readBuffer = BeginReadResponseBuffer(id, apiCalled, out result);

                    if (result.RaiseException == true) throw new NpToolkitException(result);

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.PlayedWithFeedBegin);

                    UInt32 numStories = readBuffer.ReadUInt32();

                    stories = new PlayedWithStory[numStories];

                    for (int i = 0; i < numStories; i++)
                    {
                        stories[i] = new PlayedWithStory();
                        stories[i].Read(readBuffer);
                    }

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.PlayedWithFeedEnd);

                    EndReadResponseBuffer(readBuffer);
                }
            }

            /// <summary>
            /// Gets a list of users from the "Players Met" feeds.
            /// </summary>
            /// <param name="request">The information to make the request</param>
            /// <param name="response">This response contains the return code</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int GetPlayedWith(GetPlayedWithRequest request, PlayedWithFeedResponse response)
            {
                APIResult result;

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxGetPlayedWith(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion


            #region Get Shared Videos

            /// <summary>
            /// Represents a list of videos that have been shared by a user
            /// </summary>
            public class SharedVideosResponse : ResponseBase
            {
                internal SharedVideo[] videos;

                /// <summary>
                /// The videos that were shared.
                /// </summary>
                public SharedVideo[] Videos { get { return videos; } }

                /// <summary>
                /// Read the response data from the plug-in
                /// </summary>
                /// <param name="id">The request id.</param>
                /// <param name="apiCalled">The API called.</param>
                /// <param name="request">The Request object.</param>
                protected internal override void ReadResult(UInt32 id, FunctionTypes apiCalled, RequestBase request)
                {
                    base.ReadResult(id, apiCalled, request);

                    APIResult result;

                    MemoryBuffer readBuffer = BeginReadResponseBuffer(id, apiCalled, out result);

                    if (result.RaiseException == true) throw new NpToolkitException(result);

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.SharedVideosBegin);

                    UInt32 numVideos = readBuffer.ReadUInt32();

                    videos = new SharedVideo[numVideos];

                    for (int i = 0; i < numVideos; i++)
                    {
                        videos[i] = new SharedVideo();
                        videos[i].Read(readBuffer);
                    }

                    readBuffer.CheckMarker(MemoryBuffer.BufferIntegrityChecks.SharedVideosEnd);

                    EndReadResponseBuffer(readBuffer);
                }
            }

            /// <summary>
            /// Gets system feeds of videos shared by the user.
            /// </summary>
            /// <param name="request">The information to make the request</param>
            /// <param name="response">This response contains the return code</param>
            /// <returns>If the operation is asynchronous, the function provides the request Id.</returns>
            /// <exception cref="NpToolkitException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the NpToolkit plug-in.</exception>
            public static int GetSharedVideos(GetSharedVideosRequest request, SharedVideosResponse response)
            {
                APIResult result;

                if (response.locked == true)
                {
                    throw new NpToolkitException("Response object is already locked");
                }

                int ret = PrxGetSharedVideos(request, out result);

                if (result.RaiseException == true) throw new NpToolkitException(result);

                RequestBase.FinaliseRequest(request, response, ret);

                return ret;
            }

            #endregion
        }
    }
}
