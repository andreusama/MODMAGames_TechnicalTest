
#pragma once

#include "../Includes/SonyCommonIncludes.h"
#include "../Includes/CommonTypes.h"
#include "../ErrorHandling/Errors.h"
#include "../Managed/ManagedRequest.h"
#include "../Managed/ManagedResponse.h"

#include <map>

namespace NPT
{
	// Dummy request class that simulates the same behaviour as the NpToolkit RequestBase class
	// This is used for request that are not part of NpToolkit and use the sceNpCreateAsyncRequest and sceNpCreateRequest methods
	class NpRequest : public NpToolkit2::Core::RequestBase
	{
	public:

		NpRequest(NpToolkit2::Core::ServiceType service, FunctionTypeExtended function);
		virtual ~NpRequest();

		Int32 internalRequestId; 
		Int32 managedRequestId;

		virtual MemoryBuffer& MarshalResult() = 0;
		virtual void Cleanup() = 0;
	};

	class NpRequests
	{
		static int CreateRequestId(bool async, APIResult* result);
		static void DeleteRequestId(int requestid, APIResult* result);

		static UInt32 nextRequestId;
		static SceKernelCpumask s_currentCpuMask; 

		static Mutex mutex;

	public:

		static ManagedEventCallback s_npRequestEventCallback;
		static void WakeUpManagedThread();

		static std::map<int, NpRequest *> m_RequestList;

		static bool AddRequest(NpRequest* request,  APIResult* result);
		static bool RemoveRequest(NpRequest* request,  APIResult* result);
		static int RecordRequest(NpToolkit2::Core::ResponseBase* responsePtr, NpRequest* request, int npReturnCode, APIResult* apiResult);

		static bool PollFirstRequest();

		static void SetCurrentCpuMask(SceKernelCpumask mask);

        static bool IsPendingCustomRequest(UInt32 npRequestID);
	};

}