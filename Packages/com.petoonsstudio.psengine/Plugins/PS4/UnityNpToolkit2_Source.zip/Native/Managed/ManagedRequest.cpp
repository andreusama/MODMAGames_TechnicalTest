#include "ManagedRequest.h"
#include "../ErrorHandling/Errors.h"

namespace NPT
{
	DO_EXPORT( bool, PrxAbortRequest ) (UInt32 npRequestId, APIResult* result)
	{
		int ret = NpToolkit2::Core::abortRequest(npRequestId);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			return false;
		}

		SUCCESS_RESULT(result);

		return true;
	}

	void RequestBaseManaged::CopyTo(NpToolkit2::Core::RequestBase &destination)
	{
		// The RequestBase will automatically have the Initial user filled in.
		// This can be overridden by setting a different user id.
		// However the Managed code doesn't set this and leaves it as 'Invalid' (-1) so if it
		// is not invalid it needs to be set, otherwise ignore it.
		if ( userId >= 0 )
		{
			destination.userId = userId;
		}

		destination.serviceLabel = serviceLabel;
		destination.async = async;
	}

}