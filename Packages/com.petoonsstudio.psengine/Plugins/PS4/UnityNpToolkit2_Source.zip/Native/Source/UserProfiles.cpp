#include <stdio.h>

#include "UserProfiles.h"

#include <rtc.h>
#include <libsysmodule.h>

#include "Core.h"
#include "Profile.h"
#include "Presence.h"

namespace NPT
{
	DO_EXPORT( void, PrxGetLocalLoginUserIds ) (LocalLoginUserId* userIds, Int32 maxSize, APIResult* result)
	{
		UserProfiles::GetLocalLoginUserIds(userIds, maxSize, result);
	}

	DO_EXPORT( int, PrxGetNpProfiles ) (GetNpProfilesManaged* managedRequest, APIResult* result)
	{
		return UserProfiles::GetNpProfiles(managedRequest, result);
	}

	DO_EXPORT( int, PrxGetVerifiedAccountsForTitle ) (GetVerifiedAccountsForTitleManaged* managedRequest, APIResult* result)
	{
		return UserProfiles::GetVerifiedAccountsForTitle(managedRequest, result);
	}

	DO_EXPORT( int, PrxDisplayUserProfileDialog ) (DisplayUserProfileDialogManaged* managedRequest, APIResult* result)
	{
		return UserProfiles::DisplayUserProfileDialog(managedRequest, result);
	}

	DO_EXPORT( int, PrxDisplayGriefReportingDialog ) (DisplayGriefReportingDialogManaged* managedRequest, APIResult* result)
	{
		return UserProfiles::DisplayGriefReportingDialog(managedRequest, result);
	}
	
	void UserProfiles::GetLocalLoginUserIds(LocalLoginUserId* userIds, Int32 maxSize, APIResult* result)
	{
		SceUserServiceLoginUserIdList loginIdList;
		int ret = sceUserServiceGetLoginUserIdList(&loginIdList);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			return;
		}

		bool userError = false;

		for (int i = 0; i < SCE_USER_SERVICE_MAX_LOGIN_USERS; i++) 
		{
			userIds[i].userId = loginIdList.userId[i];
			userIds[i].accountId = 0;

			if (loginIdList.userId[i] != SCE_USER_SERVICE_USER_ID_INVALID) 
			{
				int ret = sceNpGetAccountIdA(userIds[i].userId, &userIds[i].accountId);

				userIds[i].sceErrorCode = ret;

				if (ret < 0)
				{
					if ( ret != SCE_NP_ERROR_SIGNED_OUT && ret != SCE_NP_ERROR_NOT_SIGNED_UP )
					{
						userError = true;
					}
				}
			}
		}

		if ( userError == true )
		{
			ERROR_RESULT(result, "One or more users have and error code associated with their account id");
			return;
		}

		SUCCESS_RESULT(result);
	}
	//
	//
	// Get Np Profiles
	//
	//
	void GetNpProfilesManaged::CopyTo(NpToolkit2::UserProfile::Request::GetNpProfiles &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.numValidAccountIds = numValidAccountIds;

		for(int i = 0; i < numValidAccountIds; i++)
		{
			destination.accountIds[i] = accountIds[i];
		}
	}

	int UserProfiles::GetNpProfiles(GetNpProfilesManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptProfilesResponse* nptResponse = new NptProfilesResponse();

		NpToolkit2::UserProfile::Request::GetNpProfiles nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::UserProfile::getNpProfiles(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	void GetVerifiedAccountsForTitleManaged::CopyTo(NpToolkit2::UserProfile::Request::GetVerifiedAccountsForTitle &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.limit = limit;
	}

	int UserProfiles::GetVerifiedAccountsForTitle(GetVerifiedAccountsForTitleManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptProfilesResponse* nptResponse = new NptProfilesResponse();

		NpToolkit2::UserProfile::Request::GetVerifiedAccountsForTitle nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::UserProfile::getVerifiedAccountsForTitle(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	void DisplayUserProfileDialogManaged::CopyTo(NpToolkit2::UserProfile::Request::DisplayUserProfileDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.targetAccountId = targetAccountId;
	}

	int UserProfiles::DisplayUserProfileDialog(DisplayUserProfileDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::UserProfile::Request::DisplayUserProfileDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::UserProfile::displayUserProfileDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	void DisplayGriefReportingDialogManaged::CopyTo(NpToolkit2::UserProfile::Request::DisplayGriefReportingDialog &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.targetAccountId = targetAccountId;

		destination.reportOnlineId = reportOnlineId;
		destination.reportName = reportName;
		destination.reportPicture = reportPicture;
		destination.reportAboutMe = reportAboutMe;
	}

	int UserProfiles::DisplayGriefReportingDialog(DisplayGriefReportingDialogManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		Core::NptEmptyResponse* nptResponse = new Core::NptEmptyResponse();

		NpToolkit2::UserProfile::Request::DisplayGriefReportingDialog nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::UserProfile::displayGriefReportingDialog(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}

		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	void UserProfiles::MarshalNpProfiles(NptProfilesResponse* response, MemoryBuffer& buffer, APIResult* result)
	{
		const NptProfiles* npProfiles = response->get();

		UInt32 numProfiles = npProfiles->numNpProfiles;

		buffer.WriteMarker(BufferIntegrityChecks::NpProfilesBegin);

		buffer.WriteUInt32((UInt32)numProfiles);

		for(int i = 0; i < numProfiles; i++)
		{
			Profile::WriteToBuffer(npProfiles->npProfiles[i], buffer);
		}

		buffer.WriteMarker(BufferIntegrityChecks::NpProfilesEnd);

		SUCCESS_RESULT(result);
	}

}