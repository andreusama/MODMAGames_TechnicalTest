#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	class FilterCommentManaged : public RequestBaseManaged
	{
	public:

		char comment[NpToolkit2::Wordfilter::Request::FilterComment::MAX_SIZE_COMMENT + 1];	

		void CopyTo(NpToolkit2::Wordfilter::Request::FilterComment &destination);
	};	

	class WordFilter
	{
	public:

		typedef NpToolkit2::Wordfilter::SanitizedComment NptSanitizedComment;
		typedef NpToolkit2::Core::Response<NptSanitizedComment> NptSanitizedCommentResponse;

		//Requests
		static int FilterComment(FilterCommentManaged* managedRequest, APIResult* result);

		// Marshal methods
		static void MarshalSanitizedComment(NptSanitizedCommentResponse* response, MemoryBuffer& buffer, APIResult* result);
	};
}





