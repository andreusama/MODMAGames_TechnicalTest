#pragma once

#include "../Includes/PluginCommonIncludes.h"
#include "../Source/Core.h"

namespace NPT
{
	class GetFriendsManaged : public RequestBaseManaged
	{
	public:
		NpToolkit2::Friend::FriendsRetrievalMode mode;	///< The specific mode for the request
		unsigned int limit;				    ///< The number of friends to be requested in a single call. If set to 0, all friends will be retrieved and offset will be ignored as well
		unsigned int offset;				///< The offset into the list of the users friends at which to start retrieving friends

		void CopyTo(NpToolkit2::Friend::Request::GetFriends &destination);
	};

	class GetFriendsOfFriendsManaged : public RequestBaseManaged
	{
	public:
		SceNpAccountId	accountIds[(NpToolkit2::Friend::Request::GetFriendsOfFriends::MAX_ACCOUNT_IDS)];	///< The account IDs of the user's friends
		UInt32			numAccountIds;					///< The number of account IDs specified

		void CopyTo(NpToolkit2::Friend::Request::GetFriendsOfFriends &destination);
	};

	class GetBlockedUsersManaged : public RequestBaseManaged
	{
	public:
		NpToolkit2::Friend::BlockedUsersRetrievalMode mode;	///< The specific mode for the request
		unsigned int limit;				    ///< The number of friends to be requested in a single call. If set to 0, all friends will be retrieved and offset will be ignored as well
		unsigned int offset;				///< The offset into the list of the users friends at which to start retrieving friends

		void CopyTo(NpToolkit2::Friend::Request::GetBlockedUsers &destination);
	};

	class DisplayFriendRequestDialogManaged : public RequestBaseManaged
	{
	public:
		SceNpAccountId	targetUser;		///< The user to send a friend request to

		void CopyTo(NpToolkit2::Friend::Request::DisplayFriendRequestDialog &destination);
	};

	class DisplayBlockUserDialogManaged : public RequestBaseManaged
	{
	public:
		SceNpAccountId	targetUser;		///< The user to block

		void CopyTo(NpToolkit2::Friend::Request::DisplayBlockUserDialog &destination);
	};

	class Friends
	{
	private:

	public:

		typedef NpToolkit2::Friend::Friends NptFriends;
		typedef NpToolkit2::Core::Response<NptFriends> NptFriendsResponse;

		typedef NpToolkit2::Friend::FriendsOfFriends NptFriendsOfFriends;
		typedef NpToolkit2::Core::Response<NptFriendsOfFriends> NptFriendsOfFriendsResponse;

		typedef NpToolkit2::Friend::BlockedUsers NptBlockedUsers;
		typedef NpToolkit2::Core::Response<NptBlockedUsers> NptBlockedUsersResponse;

		typedef NpToolkit2::Friend::Notification::FriendlistUpdate NptFriendlistUpdate;
		typedef NpToolkit2::Core::Response<NptFriendlistUpdate> NptFriendlistUpdateResponse;

		typedef NpToolkit2::Friend::Notification::BlocklistUpdate NptBlocklistUpdate;
		typedef NpToolkit2::Core::Response<NptBlocklistUpdate> NptBlocklistUpdateResponse;

		// Request Methods
		static int GetFriends(GetFriendsManaged* managedRequest, APIResult* result);
		static int GetFriendsOfFriends(GetFriendsOfFriendsManaged* managedRequest, APIResult* result);
		static int GetBlockedUsers(GetBlockedUsersManaged* managedRequest, APIResult* result);
		static int DisplayFriendRequestDialog(DisplayFriendRequestDialogManaged* managedRequest, APIResult* result);
		static int DisplayBlockUserDialog(DisplayBlockUserDialogManaged* managedRequest, APIResult* result);

		// Marshal methods
		static void MarshalFriends(NptFriendsResponse* response, MemoryBuffer& buffer, APIResult* result);

		static void MarshalFriendsOfFriends(NptFriendsOfFriendsResponse* response, MemoryBuffer& buffer, APIResult* result);

		static void MarshalBlockedUsers(NptBlockedUsersResponse* response, MemoryBuffer& buffer, APIResult* result);

		static void WriteToBuffer(NpToolkit2::Friend::Friend& npFriend, MemoryBuffer& buffer); 

		// Notification Responses
		static void MarshalFriendlistUpdate(NptFriendlistUpdateResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalBlocklistUpdate(NptBlocklistUpdateResponse* response, MemoryBuffer& buffer, APIResult* result);

	private:

	};
}





