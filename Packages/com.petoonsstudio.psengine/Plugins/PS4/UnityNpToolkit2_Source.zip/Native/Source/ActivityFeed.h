#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	class GetFeedManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::ActivityFeed::Request::GetFeed &destination);

		SceNpAccountId	user;
		NpToolkit2::ActivityFeed::FeedType type;
		UInt32 offset;
		UInt32 pageSize;
	};	

	struct ButtonCaption
	{
		void CopyTo(NpToolkit2::ActivityFeed::ButtonCaption &destination);

		char languageCode[SCE_NP_LANGUAGE_CODE_MAX_LEN + 1];
		char text[NpToolkit2::ActivityFeed::ButtonCaption::TEXT_MAX_LEN + 1];
	};

	struct ActionManaged
	{
		void CopyTo(NpToolkit2::ActivityFeed::Action &destination);

		char imageUrl[NpToolkit2::ActivityFeed::Action::URL_MAX_LEN+1];
		char uri[NpToolkit2::ActivityFeed::Action::URL_MAX_LEN+1];
		char storeLabel[NpToolkit2::ActivityFeed::Action::STORE_LABEL_MAX_LEN+1];

		char startGameArguments[NpToolkit2::ActivityFeed::Action::START_GAME_ARGS_MAX+1];

		ButtonCaption buttonCaptions[NpToolkit2::ActivityFeed::Action::MAX_BUTTON_CAPTIONS];
		SceNpServiceLabel storeServiceLabel;
		NpToolkit2::ActivityFeed::ActionType type;
	};

	struct MediaManaged
	{
		void CopyTo(NpToolkit2::ActivityFeed::Media &destination);

		char largeImageUrl[NpToolkit2::ActivityFeed::Media::URL_MAX_LEN + 1];
		char videoUrl[NpToolkit2::ActivityFeed::Media::URL_MAX_LEN + 1];
	};

	struct CaptionManaged
	{
		void CopyTo(NpToolkit2::ActivityFeed::Caption &destination);

		char languageCode[SCE_NP_LANGUAGE_CODE_MAX_LEN + 1];
		char caption[NpToolkit2::ActivityFeed::Caption::CAPTION_MAX_LEN + 1];
	};

	class PostInGameStoryManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::ActivityFeed::Request::PostInGameStory &destination);

		ActionManaged actions[NpToolkit2::ActivityFeed::Request::PostInGameStory::MAX_ACTIONS];

		CaptionManaged captions[1024];
		UInt32 numCaptions;

		CaptionManaged condensedCaptions[1024];
		UInt32 numCondensedCaptions;

		MediaManaged media;

		Int32 subType;

		char userComment[NpToolkit2::ActivityFeed::Request::PostInGameStory::USER_COMMENT_MAX_LEN + 1];
	};


	struct StoryIdManaged
	{
		void CopyTo(NpToolkit2::ActivityFeed::StoryId &destination);

		char id[NpToolkit2::ActivityFeed::StoryId::STORY_ID_LEN + 1];
	};

	class SetLikedManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::ActivityFeed::Request::SetLiked &destination);

		StoryIdManaged	storyId;
		bool isLiked;
	};

	class GetWhoLikedManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::ActivityFeed::Request::GetWhoLiked &destination);

		SceNpAccountId	lastUserRetrieved;
		StoryIdManaged	storyId;
		UInt32		    pageSize;
	};

	class PostPlayedWithManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::ActivityFeed::Request::PostPlayedWith &destination);

		SceNpAccountId userIds[NpToolkit2::ActivityFeed::Request::PostPlayedWith::MAX_USERS];
		UInt32 numUsers;
		char playedWithDescription[NpToolkit2::ActivityFeed::Request::PostPlayedWith::DESCRIPTION_MAX_LEN + 1];
	};

	class GetPlayedWithManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::ActivityFeed::Request::GetPlayedWith &destination);
	};

	class GetSharedVideosManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::ActivityFeed::Request::GetSharedVideos &destination);

		SceNpAccountId	 user;
	};

	class ActivityFeed
	{
	public:

		typedef NpToolkit2::ActivityFeed::Feed NptFeed;
		typedef NpToolkit2::Core::Response<NptFeed> NptFeedResponse;

		typedef NpToolkit2::ActivityFeed::UsersWhoLiked NptUsersWhoLiked;
		typedef NpToolkit2::Core::Response<NptUsersWhoLiked> NptUsersWhoLikedResponse;

		typedef NpToolkit2::ActivityFeed::PlayedWithFeed NptPlayedWithFeed;
		typedef NpToolkit2::Core::Response<NptPlayedWithFeed> NptPlayedWithFeedResponse;

		typedef NpToolkit2::ActivityFeed::SharedVideos NptSharedVideos;
		typedef NpToolkit2::Core::Response<NptSharedVideos> NptSharedVideosResponse;


		//Requests
		static int GetFeed(GetFeedManaged* managedRequest, APIResult* result);
		static int PostInGameStory(PostInGameStoryManaged* managedRequest, APIResult* result);
		static int SetLiked(SetLikedManaged* managedRequest, APIResult* result);
		static int GetWhoLiked(GetWhoLikedManaged* managedRequest, APIResult* result);

		static int PostPlayedWith(PostPlayedWithManaged* managedRequest, APIResult* result);
		static int GetPlayedWith(GetPlayedWithManaged* managedRequest, APIResult* result);
		static int GetSharedVideos(GetSharedVideosManaged* managedRequest, APIResult* result);

		// Marshal methods
		static void MarshalFeed(NptFeedResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalUsersWhoLiked(NptUsersWhoLikedResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalPlayedWithFeed(NptPlayedWithFeedResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalSharedVideos(NptSharedVideosResponse* response, MemoryBuffer& buffer, APIResult* result);


		static void WriteToBuffer(const NpToolkit2::ActivityFeed::Story& story, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::ActivityFeed::PlayedWithStory& story, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::ActivityFeed::SharedVideo& video, MemoryBuffer& buffer);

		static void WriteToBuffer(const NpToolkit2::ActivityFeed::StoryId& storyId, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::ActivityFeed::StoryUser& storyUser, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::ActivityFeed::Media& media, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::ActivityFeed::Caption& caption, MemoryBuffer& buffer);
	};
}





