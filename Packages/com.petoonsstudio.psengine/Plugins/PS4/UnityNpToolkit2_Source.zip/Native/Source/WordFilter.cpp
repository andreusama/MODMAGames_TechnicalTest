
#include "WordFilter.h"

#include "Core.h"

namespace NPT
{
	DO_EXPORT( int, PrxFilterComment ) (FilterCommentManaged* managedRequest, APIResult* result)
	{
		return WordFilter::FilterComment(managedRequest, result);
	}

	void FilterCommentManaged::CopyTo(NpToolkit2::Wordfilter::Request::FilterComment &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		strcpy_s(destination.comment, NpToolkit2::Wordfilter::Request::FilterComment::MAX_SIZE_COMMENT + 1, comment);
	}

	int WordFilter::FilterComment(FilterCommentManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptSanitizedCommentResponse* nptResponse = new NptSanitizedCommentResponse();

		NpToolkit2::Wordfilter::Request::FilterComment nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::Wordfilter::filterComment(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	// Marshal responses
	void WordFilter::MarshalSanitizedComment(NptSanitizedCommentResponse* response, MemoryBuffer& buffer, APIResult* result)
	{		
		buffer.WriteMarker(BufferIntegrityChecks::WordFilterBegin);

		const NptSanitizedComment* sanitizedComment = response->get();

		buffer.WriteString(sanitizedComment->resultComment,sanitizedComment->resultCommentValidSize);
		buffer.WriteBool(sanitizedComment->isCommentChanged);

		buffer.WriteMarker(BufferIntegrityChecks::WordFilterEnd);

		SUCCESS_RESULT(result);
	}

}
