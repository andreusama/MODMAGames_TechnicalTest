#include <stdlib.h>
#include <stdio.h>
#include <libsysmodule.h>

#include "MainNPT.h"

// This class is constructed with a very low global static instantiation value, and so we can loadup the np toolkit library before all the global futures get created
class PreStartup
{
public:
	PreStartup()
	{
		NPT::Main::LoadModules();
		/*int res = sceSysmoduleLoadModule(SCE_SYSMODULE_NP_TOOLKIT2);
		if (res != 0)
		{
			printf("Error loading SCE_SYSMODULE_NP_TOOLKIT, 0x%x\n", res);
		}*/
	}
};
PreStartup preStartup __attribute__((init_priority(101)));

// This is called from sceKernelLoadStartModule() after global static instantiation
//int module_start(size_t, const void*)
//{
//	return 0;
//}


