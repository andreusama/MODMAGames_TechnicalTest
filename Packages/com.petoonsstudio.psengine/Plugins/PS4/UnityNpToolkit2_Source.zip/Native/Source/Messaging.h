#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	class SendInGameMessageManaged : public RequestBaseManaged
	{
	public:

		UInt64 messageSize;	
		char message[SCE_NP_IN_GAME_MESSAGE_DATA_SIZE_MAX];
		SceNpAccountId recipientId;				///< The recipient to receive the message
		NpToolkit2::Messaging::PlatformType recipientPlatformType;		///< The platform of the recipient receiving the message

		void CopyTo(NpToolkit2::Messaging::Request::SendInGameMessage &destination);
	};	

#if (SCE_ORBIS_SDK_VERSION <= 0x07099999)
	class DisplayReceivedGameDataMessagesDialogManaged : public RequestBaseManaged
	{
	public:

		void CopyTo(NpToolkit2::Messaging::Request::DisplayReceivedGameDataMessagesDialog &destination);
	};

	struct GameDataMessageImageManaged
	{
		char imgPath[NpToolkit2::Messaging::Request::GameDataMessageImage::IMAGE_PATH_MAX_LEN + 1];

		void CopyTo(NpToolkit2::Messaging::Request::GameDataMessageImage &destination);
	};

	struct LocalizedMetadataManaged
	{
		char languageCode[SCE_NP_LANGUAGE_CODE_MAX_LEN+1];
		char name[NpToolkit2::Messaging::Request::LocalizedMetadata::MAX_SIZE_DATA_NAME + 1];
		char description[NpToolkit2::Messaging::Request::LocalizedMetadata::MAX_SIZE_DATA_DESCRIPTION + 1];

		void CopyTo(NpToolkit2::Messaging::Request::LocalizedMetadata &destination);
	};

	class SendGameDataMessageManaged : public RequestBaseManaged
	{
	public:

		const static int32_t MAX_LOCALIZED_METADATA = 50;

		char textMessage[NpToolkit2::Messaging::Request::SendGameDataMessage::MAX_SIZE_TEXT_MESSAGE + 1];
		char dataName[NpToolkit2::Messaging::Request::SendGameDataMessage::MAX_SIZE_DATA_NAME + 1];				
		char dataDescription[NpToolkit2::Messaging::Request::SendGameDataMessage::MAX_SIZE_DATA_DESCRIPTION + 1];		

		UInt32 numRecipients;
		SceNpAccountId recipients[NpToolkit2::Messaging::Request::SendGameDataMessage::MAX_NUM_RECIPIENTS];

		NpToolkit2::Messaging::GameCustomDataType type;

		UInt32 expireMinutes;

		void *attachment;
		UInt64 attachmentSize;

		char url[NpToolkit2::Messaging::Request::SendGameDataMessage::MAX_URL_SIZE + 1];		

		UInt64 numDataLocalized;
		LocalizedMetadataManaged dataLocalized[MAX_LOCALIZED_METADATA];

		GameDataMessageImageManaged thumbnail;

		UInt32 maxNumberRecipientsToAdd;	///< If the dialog is enabled and the sender user can edit the recipients, then the maximum number of recipients the sender user can add must be specified
		bool enableDialog;					///< If a dialog is displayed to the sender user or the message is directly sent from the application without user interaction
		bool senderCanEditRecipients;		///< In case the dialog is enabled, this boolean specifies if the sender user can modify the recipients. If <c>true</c> then set <c>maxNumberRecipientsToAdd</c>. If <c>false</c> then set <c>recipients</c>
		bool isPS4Available;				///< If the message is sent to a PS4 platform
		bool isPSVitaAvailable;				///< If the message is sent to a PS Vita platform

		bool addGameDataMsgIdToUrl;			///< When set to <c>true</c>, it will append "&itemId=<value>" at the end of the URL specified in <c>url</c> so the custom data message Id can be sent on the URL, perhaps to be recognized by the hosting server		

		void CopyTo(NpToolkit2::Messaging::Request::SendGameDataMessage &destination);
	};	

	class ConsumeGameDataMessageManaged : public RequestBaseManaged
	{
	public:
		UInt64 gameDataMsgId;

		void CopyTo(NpToolkit2::Messaging::Request::ConsumeGameDataMessage &destination);
	};	

	class GetReceivedGameDataMessagesManaged : public RequestBaseManaged
	{
	public:

		UInt64 numGameDataMsgIds;
		UInt64 gameDataMsgIds[NpToolkit2::Messaging::Request::GetReceivedGameDataMessages::MAX_NUM_GAME_DATA_MSG_IDS];
		UInt32 pageSize;
		UInt32 offset;
		NpToolkit2::Messaging::Request::GameDataMessagesToRetrieve type;

		void CopyTo(NpToolkit2::Messaging::Request::GetReceivedGameDataMessages &destination);
	};

	class GetGameDataMessageThumbnailManaged : public RequestBaseManaged
	{
	public:
		UInt64 gameDataMsgId;

		void CopyTo(NpToolkit2::Messaging::Request::GetGameDataMessageThumbnail &destination);
	};

	class GetGameDataMessageAttachmentManaged : public RequestBaseManaged
	{
	public:
		UInt64 gameDataMsgId;

		void CopyTo(NpToolkit2::Messaging::Request::GetGameDataMessageAttachment &destination);
	};	
#endif

	class Messaging
	{
	public:

		typedef NpToolkit2::Messaging::Notification::NewInGameMessage NptNewInGameMessage;
		typedef NpToolkit2::Core::Response<NptNewInGameMessage> NptNewInGameMessageResponse;

		static int SendInGameMessage(SendInGameMessageManaged* managedRequest, APIResult* result);

		static void MarshalNewInGameMessage(NptNewInGameMessageResponse* response, MemoryBuffer& buffer, APIResult* result);

		// System Events
		static void HandleGameCustomDataEvent(SceNpGameCustomDataEventParam* eventParam);

#if (SCE_ORBIS_SDK_VERSION <= 0x07099999)
		typedef NpToolkit2::Messaging::GameDataMessages NptGameDataMessages;
		typedef NpToolkit2::Core::Response<NptGameDataMessages> NptGameDataMessagesResponse;

		typedef NpToolkit2::Messaging::GameDataMessageThumbnail NptGameDataMessageThumbnail;
		typedef NpToolkit2::Core::Response<NptGameDataMessageThumbnail> NptGameDataMessageThumbnailResponse;

		typedef NpToolkit2::Messaging::GameDataMessageAttachment NptGameDataMessageAttachment;
		typedef NpToolkit2::Core::Response<NptGameDataMessageAttachment> NptGameDataMessageAttachmentResponse;	

		typedef NpToolkit2::Messaging::Notification::NewGameDataMessage NptNewGameDataMessage;
		typedef NpToolkit2::Core::Response<NptNewGameDataMessage> NptNewGameDataMessageResponse;

		//Requests
		static int DisplayReceivedGameDataMessagesDialog(DisplayReceivedGameDataMessagesDialogManaged* managedRequest, APIResult* result);
		static int SendGameDataMessage(SendGameDataMessageManaged* managedRequest, APIResult* result);
		static int ConsumeGameDataMessage(ConsumeGameDataMessageManaged* managedRequest, APIResult* result);
		static int GetReceivedGameDataMessages(GetReceivedGameDataMessagesManaged* managedRequest, APIResult* result);
		static int GetGameDataMessageThumbnail(GetGameDataMessageThumbnailManaged* managedRequest, APIResult* result);
		static int GetGameDataMessageAttachment(GetGameDataMessageAttachmentManaged* managedRequest, APIResult* result);

		// Marshal methods
		static void MarshalGameDataMessages(NptGameDataMessagesResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalGameDataMessageThumbnail(NptGameDataMessageThumbnailResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalGameDataMessageAttachment(NptGameDataMessageAttachmentResponse* response, MemoryBuffer& buffer, APIResult* result);

		// Notification
		
		static void MarshalNewGameDataMessage(NptNewGameDataMessageResponse* response, MemoryBuffer& buffer, APIResult* result);

		// Write Methods
		static void WriteToBuffer(const NpToolkit2::Messaging::GameDataMessage& gameDataMessage, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::Messaging::GameDataMessageDetails& gmeDataMessageDetails, MemoryBuffer& buffer);
#endif
	};


}





