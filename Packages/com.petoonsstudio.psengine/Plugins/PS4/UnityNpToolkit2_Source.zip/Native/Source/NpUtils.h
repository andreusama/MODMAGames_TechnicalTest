#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	class SetTitleIdForDevelopmentManaged : public RequestBaseManaged
	{
	public:
	
		char* titleId;  // [SCE_NP_TITLE_ID_LEN + 1];					///< The title id to be set
		char* titleSecretString; // [NpToolkit2::NpUtils::Request::SetTitleIdForDevelopment::TITLE_SECRET_STRING_MAX_SIZE];	///< The title secret to be set. This is the same string set in the .txt file given on DevNet
		UInt32 titleSecretStringSize;							///< The size of titleSecretString

		void CopyTo(NpToolkit2::NpUtils::Request::SetTitleIdForDevelopment &destination);
	};	

	class DisplaySigninDialogManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::NpUtils::Request::DisplaySigninDialog &destination);
	};	

	class CheckAvailablityManaged : public RequestBaseManaged
	{
	public:
		void CopyTo(NpToolkit2::NpUtils::Request::CheckAvailability &destination);
	};	

	// CheckPlus
	class CheckPlusRequest : public NpRequest
	{
	public:

		CheckPlusRequest();

		SceNpCheckPlusParameter* parameters;
		SceNpCheckPlusResult* results;

		MemoryBuffer& MarshalResult();
		void Cleanup();
	};

	class CheckPlusManaged : public RequestBaseManaged
	{
	public:

		UInt64 features;  // Defualts to SCE_NP_PLUS_FEATURE_REALTIME_MULTIPLAY.

		void CopyTo(CheckPlusRequest &destination);
	};	

	// sceNpGetParentalControlInfoA
	class GetParentalControlInfoRequest : public NpRequest
	{
	public:

		GetParentalControlInfoRequest();

		SceUserServiceUserId userId;
		int8_t age;
		SceNpParentalControlInfo *parentalControlInfo;

		MemoryBuffer& MarshalResult();
		void Cleanup();
	};

	class GetParentalControlInfoManaged : public RequestBaseManaged
	{
	public:

		void CopyTo(GetParentalControlInfoRequest &destination);
	};	

	class NpUtils
	{
	public:

		typedef NpToolkit2::NpUtils::Notification::UserStateChange NptUserStateChange;
		typedef NpToolkit2::Core::Response<NpToolkit2::NpUtils::Notification::UserStateChange> NptUserStateChangeResponse;

		// Imediate methods - not requests.
		static void NotifyPlusFeature(SceUserServiceUserId userId, uint64_t features, APIResult* result);

		//Requests
		static int SetTitleIdForDevelopment(SetTitleIdForDevelopmentManaged* managedRequest, APIResult* result);
		static int DisplaySigninDialog(DisplaySigninDialogManaged* managedRequest, APIResult* result);
		static int CheckAvailablity(CheckAvailablityManaged* managedRequest, APIResult* result);
		static int CheckPlus(CheckPlusManaged* managedRequest, APIResult* result);
		static int GetParentalControlInfo(GetParentalControlInfoManaged* managedRequest, APIResult* result);

		// Marshal methods
		static void MarshalUserStateChange(NptUserStateChangeResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalCheckPlus(NptUserStateChangeResponse* response, MemoryBuffer& buffer, APIResult* result);
	};
}





