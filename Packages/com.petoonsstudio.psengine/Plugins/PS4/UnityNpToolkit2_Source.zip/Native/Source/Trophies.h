#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	class RegisterTrophyPackManaged : public RequestBaseManaged
	{
	public:

		void CopyTo(NpToolkit2::Trophy::Request::RegisterTrophyPack &destination);
	};

	class UnlockTrophyManaged : public RequestBaseManaged
	{
	public:
		SceNpTrophyId trophyId;

		void CopyTo(NpToolkit2::Trophy::Request::Unlock &destination);
	};	

	class SetScreenshotManaged : public RequestBaseManaged
	{
	public:
	
		const static int32_t MAX_SCREENSHOT_TROPHIES = 4;

		Int32 trophiesIds[MAX_SCREENSHOT_TROPHIES]; ///< An array with the trophy Ids to be assigned to the screenshot once it is taken. A maximum of <c>MAX_NUMBER_TROPHIES</c>
		UInt32 numTrophiesIds; ///< The number of valid elements in the <i><c>trophiesIds</c></i> array                                                        
		bool assignToAllUsers; ///< True by default. Specify if the screenshot taken should be associated with all logged in users for the trophies specified in the <i><c>trophiesIds</c></i> array          				

		void CopyTo(NpToolkit2::Trophy::Request::SetScreenshot &destination);
	};	

	class GetUnlockedTrophiesManaged : public RequestBaseManaged
	{
	public:

		void CopyTo(NpToolkit2::Trophy::Request::GetUnlockedTrophies &destination);
	};

	class DisplayTrophyListDialogManaged : public RequestBaseManaged
	{
	public:

		void CopyTo(NpToolkit2::Trophy::Request::DisplayTrophyListDialog &destination);
	};

	class GetTrophyPackSummaryManaged : public RequestBaseManaged
	{
	public:
		bool retrieveTrophyPackSummaryIcon;			///< False by default. Set it to true to return the icon for the trophy package

		void CopyTo(NpToolkit2::Trophy::Request::GetTrophyPackSummary &destination);
	};

	class GetTrophyPackGroupManaged : public RequestBaseManaged
	{
	public:
		
		SceNpTrophyGroupId groupId;					///< The group to return the information from
		bool retrieveTrophyPackGroupIcon;			///< False by default. Set it to true to return the icon for the group

		void CopyTo(NpToolkit2::Trophy::Request::GetTrophyPackGroup &destination);
	};

	class GetTrophyPackTrophyManaged : public RequestBaseManaged
	{
	public:
		
		SceNpTrophyId trophyId;						///< The trophy to return the information from
		bool retrieveTrophyPackTrophyIcon;			///< False by default. Set it to true to return the icon for the trophy 

		void CopyTo(NpToolkit2::Trophy::Request::GetTrophyPackTrophy &destination);
	};
	
	class Trophies
	{
	public:

		typedef NpToolkit2::Trophy::UnlockedTrophies NptUnlockedTrophies;
		typedef NpToolkit2::Core::Response<NptUnlockedTrophies> NptUnlockedTrophiesResponse;

		typedef NpToolkit2::Trophy::TrophyPackSummary NptTrophyPackSummary;
		typedef NpToolkit2::Core::Response<NptTrophyPackSummary> NptTrophyPackSummaryResponse;

		typedef NpToolkit2::Trophy::TrophyPackGroup NptTrophyPackGroup;
		typedef NpToolkit2::Core::Response<NptTrophyPackGroup> NptTrophyPackGroupResponse;

		typedef NpToolkit2::Trophy::TrophyPackTrophy NptTrophyPackTrophy;
		typedef NpToolkit2::Core::Response<NptTrophyPackTrophy> NptTrophyPackTrophyResponse;

		// Request Methods
		static int RegisterTrophyPack(RegisterTrophyPackManaged* managedRequest, APIResult* result);
		static int UnlockTrophy(UnlockTrophyManaged* managedRequest, APIResult* result);
		static int SetScreenshot(SetScreenshotManaged* managedRequest, APIResult* result);
		static int GetUnlockedTrophies(GetUnlockedTrophiesManaged* managedRequest, APIResult* result);
		static int DisplayTrophyListDialog(DisplayTrophyListDialogManaged* managedRequest, APIResult* result);
		static int GetTrophyPackSummary(GetTrophyPackSummaryManaged* managedRequest, APIResult* result);
		static int GetTrophyPackGroup(GetTrophyPackGroupManaged* managedRequest, APIResult* result);
		static int GetTrophyPackTrophy(GetTrophyPackTrophyManaged* managedRequest, APIResult* result);

		// Notification Copies

		// Marshal methods
		static void MarshalUnlockedTrophies(NptUnlockedTrophiesResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalTrophyPackSummary(NptTrophyPackSummaryResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalTrophyPackGroup(NptTrophyPackGroupResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalTrophyPackTrophy(NptTrophyPackTrophyResponse* response, MemoryBuffer& buffer, APIResult* result);

		// Write Methods
		static void WriteToBuffer(const SceNpTrophyGameDetails& sceNpTrophyGameDetails, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpTrophyGameData& sceNpTrophyGameData, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpTrophyGroupDetails& sceNpTrophyGroupDetails, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpTrophyGroupData& sceNpTrophyGroupData, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNpTrophyDetails& sceNpTrophyDetails, MemoryBuffer& buffer);
	    static void WriteToBuffer(const SceNpTrophyData& sceNpTrophyData, MemoryBuffer& buffer);

	};
}





