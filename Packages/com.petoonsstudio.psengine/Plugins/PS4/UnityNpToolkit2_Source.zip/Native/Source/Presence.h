#pragma once

#include "../Includes/PluginCommonIncludes.h"
#include "Core.h"

namespace NPT
{
	class DeletePresenceManaged : public RequestBaseManaged
	{
	public:
		bool deleteGameData;	///< When set to <c>true</c>, game data of the calling user will be deleted
		bool deleteGameStatus; ///< When set to <c>true</c>, all game statuses of the calling user (default and localized) will be deleted

		void CopyTo(NpToolkit2::Presence::Request::DeletePresence &destination);
	};

	struct LocalizedGameStatusManaged
	{
	public:
		const static int32_t MAX_SIZE_LOCALIZED_GAME_STATUS = 96; ///< The maximum size of the <i><c>gameStatus</c></i> array

		char languageCode[SCE_NP_LANGUAGE_CODE_MAX_LEN+1];		///< The localized game status provided is written in this language. Five digits format (countryCode-language) + null terminator
		char gameStatus[MAX_SIZE_LOCALIZED_GAME_STATUS+1];	    ///< A localized string for the game status. It will be provided when users have the paired language as the system software language. UTF-8 format
	};

	class SetPresenceManaged : public RequestBaseManaged
	{
	public:
		//const static int32_t MAX_SIZE_DEFAULT_GAME_STATUS = 191; ///< The maximum size of the default game status that will be shown for users whose localized game status is not found
		//const static int32_t MAX_SIZE_GAME_DATA = 128;			///< The maximum size of the binary game data array

		const static int32_t MAX_LOCALIZED_STATUSES = 50;			///< The maximum size of the localizedGameStatuses array

		char defaultGameStatus[NpToolkit2::Presence::Request::SetPresence::MAX_SIZE_DEFAULT_GAME_STATUS];	///< A default string identifying the status (level, etc.) the user is in. It will be shown in "Now Playing" on the user profile
		LocalizedGameStatusManaged localizedGameStatuses[MAX_LOCALIZED_STATUSES]; ///< An array of localizations for the game status. If the system language on the console matches one of the languages, the game status used by the system and provided to the application will be the matching one. This pointer is copied internally and can be freed as soon as the function returns
		UInt32 numLocalizedGameStatuses;			///< The size of the localizedGameStatuses array
		char binaryGameData[NpToolkit2::Presence::Request::SetPresence::MAX_SIZE_GAME_DATA];	///< Binary data the user can set for the game. It can be retrieved by other users (it can contain a session Id, room Id, or any information up to MAX_SIZE_GAME_DATA bytes)
		UInt32 binaryGameDataSize;					///< The size of the binary data

		void CopyTo(NpToolkit2::Presence::Request::SetPresence &destination);
	};	

	class GetPresenceManaged : public RequestBaseManaged
	{
	public:
		SceNpAccountId fromUser;	///< The user to get the presence from. It can be the calling user or a friend
		bool inContext;				///< True by default. If the presence information to be obtained is regarding the game (true) or the system (false). For more information, see <c>Presence</c> class

		void CopyTo(NpToolkit2::Presence::Request::GetPresence &destination);
	};	

	// Provide Presence PRX calls to NpToolkit Presence methods
	class Presence
	{
	private:

	public:

		typedef NpToolkit2::Presence::Presence NptPresence;
		typedef NpToolkit2::Core::Response<NpToolkit2::Presence::Presence> NptPresenceResponse;

		typedef NpToolkit2::Presence::Notification::PresenceUpdate NptPresenceUpdate;
		typedef NpToolkit2::Core::Response<NptPresenceUpdate> NptPresenceUpdateResponse;

		// Requests
		static int DeletePresence(DeletePresenceManaged* managedRequest, APIResult* result);
		static int SetPresence(SetPresenceManaged* managedRequest, APIResult* result);
		static int GetPresence(GetPresenceManaged* managedRequest, APIResult* result);

		// Write
		static void WriteToBuffer(const NpToolkit2::Presence::PlatformPresence& npPlatformPresence, MemoryBuffer& buffer);
		static void WriteToBuffer(const NpToolkit2::Presence::Presence& npPresence, MemoryBuffer& buffer);

		// Marshal methods
		static void MarshalPresence(NptPresenceResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalPresenceUpdate(NptPresenceUpdateResponse* response, MemoryBuffer& buffer, APIResult* result);

	private:

	};
}





