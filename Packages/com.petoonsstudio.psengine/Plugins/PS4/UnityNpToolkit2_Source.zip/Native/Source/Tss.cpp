
#include "Tss.h"

#include "Core.h"

namespace NPT
{
	DO_EXPORT( int, PrxTssGetData ) (TssGetDataManaged* managedRequest, APIResult* result)
	{
		return TSS::GetData(managedRequest, result);
	}

	void TssGetDataManaged::CopyTo(NpToolkit2::TSS::Request::GetData &destination)
	{
		RequestBaseManaged::CopyTo(destination); // Call base class

		destination.slotId = slotId;
		destination.retrieveStatusOnly = retrieveStatusOnly;
		destination.optParamUsed = false;

		destination.optParam.size = sizeof(SceNpTssGetDataOptParam);
		destination.optParam.offset = NULL;
		destination.optParam.lastByte = NULL;
		destination.optParam.ifParam = NULL;

		if (length > 0 || lastModified.tick != 0 )
		{
			// Some of the optional parameters have been set.
			destination.optParamUsed = true;

			if ( length > 0 )
			{
				// This means both the offset and length need to be set in the optional parameters.
				// The optional parameters use pointers to two interger values.
				destination.optParam.offset = new off_t;
				destination.optParam.lastByte = new off_t;

				*destination.optParam.offset = offset;
				*destination.optParam.lastByte = offset + (length-1);
			}

			if ( lastModified.tick != 0 )
			{
				destination.optParam.ifParam = new SceNpTssIfModifiedSinceParam;
				memset(destination.optParam.ifParam, 0, sizeof(SceNpTssIfModifiedSinceParam));

				if ( destination.optParam.offset == NULL )
				{
					destination.optParam.ifParam->ifType = SCE_NP_TSS_IFTYPE_IF_MODIFIED_SINCE;
				}
				else
				{
					destination.optParam.ifParam->ifType = SCE_NP_TSS_IFTYPE_IF_RANGE;
				}

				destination.optParam.ifParam->lastModified = lastModified;
			}
		}
	}

	int TSS::GetData(TssGetDataManaged* managedRequest, APIResult* result)
	{
		AsyncCallbackAutoLock autoLock;

		NptTssDataResponse* nptResponse = new NptTssDataResponse();

		NpToolkit2::TSS::Request::GetData nptRequest;

		managedRequest->CopyTo(nptRequest);

		int ret = NpToolkit2::TSS::getData(nptRequest, nptResponse);

		if (ret < 0) 
		{
			SCE_ERROR_RESULT(result, ret);
			delete nptResponse;
			return ret;
		}
	
		ResponseMap::Add(nptResponse, nptRequest, ret);

		SUCCESS_RESULT(result);

		return ret;
	}

	// Marshal responses
	void TSS::MarshalTssData(NptTssDataResponse* response, MemoryBuffer& buffer, APIResult* result)
	{		
		buffer.WriteMarker(BufferIntegrityChecks::TssDataBegin);

		const NptTssData* tssData = response->get();

		buffer.WriteData((char*)tssData->buffer, (Int32)tssData->bufferSize);
		Core::WriteToBuffer(tssData->status.lastModified, buffer);   // SceRtcTick
		buffer.WriteInt32(tssData->status.statusCodeType);
		buffer.WriteInt64(tssData->status.contentLength);

		buffer.WriteMarker(BufferIntegrityChecks::TssDataEnd);

		SUCCESS_RESULT(result);
	}
}
