#pragma once

#include "../Includes/PluginCommonIncludes.h"

namespace NPT
{
	class GetBandwidthInfoManaged : public RequestBaseManaged 
	{
	public:

		void CopyTo(NpToolkit2::NetworkUtils::Request::GetBandwidthInfo &destination);
	};

	class GetBasicNetworkInfoManaged : public RequestBaseManaged
	{
	public:

		void CopyTo(NpToolkit2::NetworkUtils::Request::GetBasicNetworkInfo &destination);
	};

	class GetDetailedNetworkInfoManaged : public RequestBaseManaged
	{
	public:

		void CopyTo(NpToolkit2::NetworkUtils::Request::GetDetailedNetworkInfo &destination);
	};


	class NetworkUtils
	{
	public:

		typedef NpToolkit2::NetworkUtils::BandwithInfo NptBandwidthInfo;
		typedef NpToolkit2::Core::Response<NptBandwidthInfo> NptBandwidthInfoResponse;

		typedef NpToolkit2::NetworkUtils::NetStateBasic NptNetStateBasic;
		typedef NpToolkit2::Core::Response<NptNetStateBasic> NptNetStateBasicResponse;

		typedef NpToolkit2::NetworkUtils::NetStateDetailed NptNetStateDetailed;
		typedef NpToolkit2::Core::Response<NptNetStateDetailed> NptNetStateDetailedResponse;

		typedef NpToolkit2::NetworkUtils::Notification::NetStateChange NptNetStateChange;
		typedef NpToolkit2::Core::Response<NptNetStateChange> NptNetStateChangeResponse;

		// Request methods
		static int GetBandwidthInfo(GetBandwidthInfoManaged* managedRequest, APIResult* result);
		static int GetBasicNetworkInfo(GetBasicNetworkInfoManaged* managedRequest, APIResult* result); 
		static int GetDetailedNetworkInfo(GetDetailedNetworkInfoManaged* managedRequest, APIResult* result); 

		// Marshal methods
		static void MarshalBandwidthInfo(NptBandwidthInfoResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalNetStateBasic(NptNetStateBasicResponse* response, MemoryBuffer& buffer, APIResult* result);
		static void MarshalNetStateDetailed(NptNetStateDetailedResponse* response, MemoryBuffer& buffer, APIResult* result);

		// Sce Write method	
		static void WriteToBuffer(const SceNpBandwidthTestResult& sceNpBandwidthTestResult, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNetCtlNatInfo& sceNetCtlNatInfo, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNetInAddr& cceNetInAddr, MemoryBuffer& buffer);
		static void WriteToBuffer(const SceNetEtherAddr& sceNetEtherAddr, MemoryBuffer& buffer);

		// Notification Responses
		static void MarshalNetStateChange(NptNetStateChangeResponse* response, MemoryBuffer& buffer, APIResult* result);
	};
}





