#include <stdio.h>

#include "MainNPT.h"

#include <rtc.h>
#include <libsysmodule.h>

#include "Friends.h"

namespace NPT
{
	DO_EXPORT( void, PrxInitialize ) (Init::InitToolkit* init, Init::InitResult* initResult, ManagedEventCallback pendingResultsCallback, ManagedEventCallback npRequestEventCallback, APIResult* result)
	{
		Main::InitializeToolkit(*init, *initResult, pendingResultsCallback, npRequestEventCallback, result);
	}

	DO_EXPORT( bool, PrxValidateToolkit ) (Main::ValidationChecks* checks, APIResult* result)
	{
		return Main::ValidateToolkit(*checks, result);
	}

	DO_EXPORT( void, PrxUpdate ) ()
	{
		Main::Update();
	}

	DO_EXPORT( void, PrxShutDown ) ()
	{
		Main::Shutdown();
	}

	DO_EXPORT( UInt64, PrxGetNetworkTime ) ()
	{
		SceRtcTick tick;
		if(sceRtcGetCurrentNetworkTick(&tick) < 0)
		{
			return 0;
		}
		return (UInt64)tick.tick * 10;
	}

	DO_EXPORT(int, PrxGetMemoryPoolStats) (NpToolkit2::Core::MemoryPoolStats * res)
	{
		if (!res)
		{
			return SCE_NP_ERROR_INVALID_ARGUMENT;
		}
		return NpToolkit2::Core::getMemoryPoolStats(*res);
	}

	// Main Class

	// Static Initialisation
	#if defined(GLOBAL_EVENT_QUEUE)
		UnityPlugin::PS4SystemEventManager Main::s_SystemEventManager;
	#endif

	bool Main::s_Initialised = false;

	IPluginUnity* Main::s_IUnity = NULL;
	IPluginSceAppParams* Main::s_ISceAppParams = NULL;
	IPluginSceNpParams* Main::s_ISceNpParams = NULL;

	// Methods
	void Main::SetupRuntimeInterfaces()
	{
		if(g_QueryInterface)
		{
	#if defined(GLOBAL_EVENT_QUEUE)
			UnityEventQueue::IEventQueue* eventQueue =  GetRuntimeInterface<UnityEventQueue::IEventQueue>(PRX_PLUGIN_IFACE_ID_GLOBAL_EVENT_QUEUE);
			if (eventQueue)
			{
				s_SystemEventManager.Initialize(eventQueue);
			}
	#endif
			s_IUnity = GetRuntimeInterface<IPluginUnity>(PRX_PLUGIN_IFACE_ID_UNITY);
			s_ISceAppParams = GetRuntimeInterface<IPluginSceAppParams>(PRX_PLUGIN_IFACE_ID_SCE_APP_PARAMS);
			s_ISceNpParams = GetRuntimeInterface<IPluginSceNpParams>(PRX_PLUGIN_IFACE_ID_SCE_NP_PARAMS);
		}
	}

	bool Main::ValidateToolkit(ValidationChecks& validate, APIResult* result)
	{
#if (SCE_ORBIS_SDK_VERSION >= 0x04000000 && SCE_ORBIS_SDK_VERSION < 0x04500000)
		// For SDK 4.0, there is one less function type. A new method was added in 4.5
		validate.expectedNumFunctionTypes -= 1;
#endif
		if ( validate.expectedNumFunctionTypes != (UInt32)NpToolkit2::Core::FunctionType::numFunctionTypes )
		{
			ERROR_RESULT(result, "Unexpected number of function types. Possible FunctionType enum out of sync.");
			return false;
		}

		SUCCESS_RESULT(result);
		return true;
	}

	void Main::InitializeToolkit(Init::InitToolkit& init, Init::InitResult& initResult, ManagedEventCallback pendingResultsCallback, ManagedEventCallback npRequestEventCallback, APIResult* result)
	{
		if(s_Initialised)
		{
			ERROR_RESULT(result, "NpToolkit Plugin already initialised"); // Already initialised
			return;
		}

		SetupRuntimeInterfaces();

		s_Initialised = true;

		CompletedAsyncEvents::s_PendingResultsCallback = pendingResultsCallback;
		NpRequests::s_npRequestEventCallback = npRequestEventCallback;

		MemoryBuffer::Initialise();
		ResponseMap::Initialise();

		Init::InitializeToolkitInternal(init, initResult, NpToolkitCallback, result);
	}

	void Main::NpToolkitCallback(NpToolkit2::Core::CallbackEvent* event)
	{
		// Why is this lock needed? What was it initial intention?
		// There is a problem with this lock.
		// If a C# threads calls a request method, which needs to be executed synchronously, then this can cause issues, especially when notifications are generated.
		// For example:
		// 
		//  C# Thread -> Sony.NP.Matching.SetInitConfiguration -> Locks mutex -> Matching::setInitConfiguration -> Release Mutex  -- (If this is an synchronous call then it won't return until the matching system has been initialised)
		//  Toolkit thread -> Recieves Notficiation -> Calls this callback methods -> Locks mutex -> Process Event -> Release Mutex

		// Note that during a notification this function might block the main NPToolkit thread if a Synchronous request call has been made. As the NPToolkit thread will still be used internally to process blocking calls then it means
		// the call to Matching::setInitConfiguration will never return as the NPToolkit thread is now blocked. 
		// So is this lock required? The locks should probably remain in all the other Request methods to prevent calls to NpToolkit from clashing.
		// If it turns out this lock is required then maybe the locks in the Request methods need to take the 'async' flag on the request object and only actually lock the mutex if it is true. This needs some investigation.
		//AsyncCallbackAutoLock autoLock;

		// Note : This doesn't store the *event pointer as NpToolkit can free this.
		// It takes a copy of the event data which will be pumped to the 
		// managed C# code when the C# code empties the CompletedAsyncEvents queue.

		// IMPORTANT : The Response pointer if allocated by the application will remain valid until deleted.
		//           : In case of notifications, it will be allocated by the NpToolkit2 library and destroyed upon callbacks return;
		//           : Therefore for notification it is necessary to take a copy of the Response object so it can be read 
		//           : by the C# dll on a seperate thread.
		CompletedAsyncEvents::AddEvent(event);
	}

	void Main::Update()
	{

	}

	void Main::Shutdown()
	{
		NpToolkit2::Core::Request::TermParams termParams;
		int ret = NpToolkit2::Core::term(termParams);
		if (ret != 0) 
		{
			// An error occured during shutdown
			return;
		}

		MemoryBuffer::Shutdown();

		s_Initialised = false;
	}

	// Warning : This is called very early on during static initialisation so it must only load modules
	// and do nothing else.
	void Main::LoadModules()
	{
		int res = sceSysmoduleLoadModule(SCE_SYSMODULE_NP_TOOLKIT2);
		if (res != 0)
		{
			//printf("Error loading SCE_SYSMODULE_NP_TOOLKIT, 0x%x\n", res);
		}
	}

	void Main::UnloadModules()
	{
		int res = sceSysmoduleUnloadModule(SCE_SYSMODULE_NP_TOOLKIT2);
		if (res != 0)
		{
			//printf("Error loading SCE_SYSMODULE_NP_TOOLKIT, 0x%x\n", res);
		}

	}

	extern "C" int module_start(SceSize sz, const void* arg)
	{
		if (!ProcessPrxPluginArgs(sz, arg, "UnityNpToolkit2"))
		{
			// Failed.
			return SCE_KERNEL_START_NO_RESIDENT;
		}

		return SCE_KERNEL_START_SUCCESS;
	}

	void Main::HandleAppLaunchEvent(char* args, UInt32 size)
	{
		MemoryBuffer& buffer = MemoryBuffer::GetNextFreeBuffer();
		buffer.StartResponseWrite();

		buffer.WriteMarker(BufferIntegrityChecks::LaunchAppEventBegin);

		buffer.WriteData(args, size);
	
		buffer.WriteMarker(BufferIntegrityChecks::LaunchAppEventEnd);

		buffer.FinishResponseWrite();

		CompletedAsyncEvents::AddCustomNotification(FunctionTypeExtended::notificationLaunchAppEvent, buffer);
	}

}
