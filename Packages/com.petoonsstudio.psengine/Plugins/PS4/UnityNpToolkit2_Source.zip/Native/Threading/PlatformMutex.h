#ifndef __PS4PLATFORMMUTEX_H
#define __PS4PLATFORMMUTEX_H

#include <kernel.h>
#include <semaphore.h>
#include <errno.h>
#include <stdio.h>

class NonCopyable
{
public:
	NonCopyable() {}

private:
	NonCopyable(const NonCopyable&);
	NonCopyable& operator=(const NonCopyable&);
};

/**
 *	A platform/api specific mutex class. Always recursive (a single thread can lock multiple times).
 */
class PlatformMutex : public NonCopyable
{
	friend class Mutex;
protected:
	PlatformMutex();
	~PlatformMutex();

	void Lock();
	void Unlock();
	bool TryLock();

private:

	ScePthreadMutex m_Mutex;
	volatile static int32_t m_CreateIndex;
};

class PlatformSemaphore : public NonCopyable
{
public:
	void Create(unsigned int initialValue);
	void Destroy();

	void WaitForSignal();
	void Signal();
	void Reset(unsigned int initialValue) { Destroy(); Create(initialValue); }

private:
	sem_t m_Semaphore;
};

#define REPORT_SEM_ERROR(action) printf ("Failed to %s a semaphore\n", action)

inline void PlatformSemaphore::Create(unsigned int initialValue) { if (sem_init(&m_Semaphore, 0, initialValue) == -1) REPORT_SEM_ERROR ("open"); }

inline void PlatformSemaphore::Destroy() { if (sem_destroy(&m_Semaphore) == -1) REPORT_SEM_ERROR ("destroy"); }

inline void PlatformSemaphore::WaitForSignal() 
{
	int ret = 0;
	while ((ret = sem_wait(&m_Semaphore)) == -1 && errno == EINTR)
		continue;

	if( ret == -1 )
		REPORT_SEM_ERROR ("wait on");
}

inline void PlatformSemaphore::Signal() 
{
	if (sem_post(&m_Semaphore) == -1)
		REPORT_SEM_ERROR ("post to");
}

#endif // __PS4PLATFORMMUTEX_H
